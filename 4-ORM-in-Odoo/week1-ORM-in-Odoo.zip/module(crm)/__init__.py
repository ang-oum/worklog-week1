from . import controllers
from . import models
from . import report
from . import wizard

from odoo import api, SUPERUSER_ID