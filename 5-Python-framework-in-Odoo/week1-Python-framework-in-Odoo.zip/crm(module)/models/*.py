# Business object
# Declared as python class
# ORM to dB through class fields


